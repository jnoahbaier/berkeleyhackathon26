# Talegate — Full UI Redesign Prompt for Cursor

Paste this entire prompt into Cursor Chat (with your repo open) and it will rebuild
every screen to match the Talegate design system exactly.

---

## The prompt

Redesign the entire Talegate mobile app UI to match our design system exactly. I'll
describe every screen, every component, and every visual rule. Follow these
instructions precisely — don't invent anything new.

---

### Design token source of truth

All values come from `mobile/src/theme/theme.ts`. NEVER hardcode colors, sizes,
spacing, radii, or shadows — always import from theme:

```ts
import { colors, fonts, fontSize, space, radius, shadow, text as type, gradients, motion } from '../theme/theme';
```

In React Native you must set `fontFamily` (e.g. `fonts.sans.bold`), never `fontWeight`.

---

### Overall visual mood

- Background: warm parchment `colors.bgApp` (#FAF6EF) — never white, never grey
- Cards: pure white `colors.surfaceCard` with `shadow.md` and `borderRadius: radius.lg` (26)
- Corners: BIG and soft everywhere. Minimum `radius.sm` (12). Buttons always `radius.pill` (999).
- Shadows: warm-tinted, low-opacity, diffuse. Use `shadow.sm/md/lg/xl`.
- NO sharp corners, NO grey backgrounds, NO blue-purple gradients, NO emoji in UI chrome.

---

### Typography rules

- **Schibsted Grotesk** = all UI: headings, buttons, nav, labels.
  Bold headlines use `type.h1` (32px, −0.02em tracking) or `type.displayLg` (40px).
- **Newsreader serif** = story text only. Use `type.read` (20px, lineHeight 1.78) for chapter body.
  Dropcap: first letter of first paragraph, 58px, `colors.accent` (candle amber), `fonts.serif.semibold`.
- **Geist Mono** = metadata labels ONLY. Always UPPERCASE, wide tracking (0.14em).
  Use `type.label` preset. Example: `CHAPTER 12 · NIGHT 12`, `8 PAGES`.
- Sentence case everywhere. Buttons: "Read tonight's chapter", not "Read Tonight's Chapter".

---

### The dusk gradient hero

Every main screen's top section uses:
```ts
// with expo-linear-gradient:
<LinearGradient {...gradients.dusk} style={{ padding: 70, paddingBottom: 30 }} />
```
That's sage→wheat→peach→lilac (~176°). Use it large and quiet behind bold dark type.
Never use it as a button fill or on small elements.

---

### Bottom tab bar (3 tabs)

Glass pill, floating above content, positioned `bottom: 14`, `left: 16`, `right: 16`, height 68.

```ts
background: 'rgba(255,255,255,0.72)'
backdropFilter: 'blur(20px)'
borderRadius: radius.pill  // 999 — very rounded
border: '1px solid rgba(255,255,255,0.8)'
...shadow.lg
```

Tabs: **Tonight** (moon icon), **Shelf** (library icon), **Guild** (users icon).
Active tab: `colors.brand` (#423AA0 indigo), weight `fonts.sans.bold`, stroke 2.2.
Inactive: `colors.textMuted`, weight `fonts.sans.medium`, stroke 1.8.
Tab labels: 11px, `fonts.sans.semibold/medium`.
Use Lucide icons (`lucide-react-native`).

---

### Screen 1 — Tonight (home tab)

**Top hero section** (dusk gradient bg):
- Status: two glass `IconButton`s top-right/left (help-circle + user icons, glass variant).
- Mono label: `Tuesday · the hour grows late` — `type.label`, muted color, uppercase.
- Headline: `"Good evening.\nYour guild is gathering."` — `type.displayLg` or `fontSize.h1` 38px,
  `fonts.sans.bold`, `colors.textStrong`, tight leading 1.04, −0.025em tracking.

**Cards section** (padding 18, gap 16, `marginTop: -14` to overlap hero):

**Card 1 — Tonight's chapter** (`elevation="lg"`, pad 20):
- Top row: amber `Badge` ("Lit · 10:00 PM" with orange dot) + mono "8 PAGES" muted right.
- Mono label below: `CHAPTER 12 · THE EMBER GATE` in `colors.accentPressed` (candle-600).
- Serif h2: chapter title, `fonts.serif.semibold`, 25px, `colors.textStrong`.
- Serif body teaser: 16px `fonts.serif.regular`, `colors.textSecondary`, lineHeight 1.55.
- `ProgressTrack` component (indigo fill, "The Ember Gate" label, Night 12/30).
- Primary CTA: `<Button variant="accent" size="lg" full>` — "Read tonight's chapter"
  with a `book-open` Lucide icon left. Amber background, dark text.

**Card 2 — Guild** (`elevation="sm"`, pad 18):
- Left: guild name bold 16px + "2 reading now" muted 13px.
- Right: `AvatarStack` (4 avatars, 38px, guild seat colors: clay rose, sage teal, periwinkle, old gold).
- Divider (`colors.borderHairline`), then `GuildDots` showing who has/hasn't read.

**Two small cards side by side** (flex row, gap 12, each `flex: 1`, `elevation="sm"`, pad 16, interactive):
- Card A: headphones icon (`colors.brand`), "Listen instead" bold 14px, "11 min, narrated" muted 12.5px.
- Card B: message-circle icon (`colors.guild1` = clay rose), "The Hearth" bold 14px, "3 new from Kai" muted.

---

### Screen 2 — Shelf (catalog tab)

**Top hero** (dusk gradient, padding 66 top):
- Mono label: `THE TALEGATE LIBRARY · 10 TALES` muted uppercase.
- Headline: `"Pick a tale,\nthe way you'd pick a book together."` — 34px bold, −0.025em tracking.
- Featured story card: glass panel (`rgba(255,255,255,0.5)`, `backdropFilter: blur(20px)`, `radius.xl`),
  flex row with `StoryCover` (md size, gradient cover art) + meta column:
  - `Badge` "Editor's pick" (lit/amber tone).
  - Story title: `fonts.serif.semibold` 20px.
  - Teaser copy: `fonts.serif.regular` 13.5px, lineHeight 1.45.
  - `<Button variant="primary" size="sm">Open</Button>`.

**Genre filter chips** (horizontal scroll, padding 12px 20px):
Tags: All, Medieval, Sci-fi, Cosy, Noir, Horror, Myth.
Use `<Tag selected>` for active (indigo filled), `<Tag>` for inactive (hairline border).

**Two carousels** (horizontal scroll rows, gap 14 between covers):
- "Handpicked this month" — first 5 shelf items.
- "For long-distance guilds" — remaining 5.
Each cover: `StoryCover` md size, tap opens detail sheet.

**Detail sheet** (bottom sheet, `borderTopLeftRadius: radius.x2l`, `borderTopRightRadius: radius.x2l`):
- Drag handle: 40×5 pill, `colors.borderStrong`, centered.
- Content: `StoryCover` md + meta column (badge, title, "by Author", mono stats with calendar/users icons).
- Serif description 17px lineHeight 1.6 + indigo-50 tinted callout box ("Adapts to your guild").
- CTA: `<Button variant="accent" size="lg" full>Start a new tale with your guild</Button>`.

---

### Screen 3 — Guild tab

**Header** (padding 66 top):
- Mono label: `YOUR GUILD`.
- Title: "The Night Owls" — `type.h1`.
- Subtitle: "Reading **The Ember Gate** · Night 12 of 30" — 14.5px `fonts.sans.regular`.

**Member list card** (`elevation="sm"`, pad 6):
Each row (pad 12px 14px, divider between rows):
- `Avatar` (46px, guild seat color).
- Name: `fonts.sans.bold` 16px + italic serif role label 14.5px `colors.textSecondary`.
- `<Badge tone="brand">You</Badge>` on your own row.

**The Hearth section** (group chat):
Mono label `THE HEARTH` above.
Each message: `Avatar` 30px + white chat bubble (`borderRadius: "18px 18px 18px 6px"`,
`shadow.sm`, pad "10px 14px"):
- Sender name: 11px `fonts.sans.bold`, `colors.guild[seat]` color.
- Message: 14.5px `fonts.sans.regular`, `colors.textBody`, lineHeight 1.4.

---

### Screen 4 — Setup flow (step 1 of 2: guild settings)

**Step header** (pad 60 top):
- Back button (`arrow-left` icon, plain variant) + progress bar (N filled amber segments of total).
- Mono step label: `STEP 1 OF 2`.
- Title: "Set the terms of your tale." — `type.h1` 28px.
- Serif subtitle: `fonts.serif.regular` 16px, `colors.textSecondary`.

**Form fields** (gap 22, pad 18):
- **Your guild**: row of `Avatar`s (50px) with first-name labels + dashed-circle invite button.
- **Pages per night**: label/sublabel left + `Stepper` (4–14, "pages" suffix) right, flex row.
- **Players**: same pattern, `Stepper` (2–4).
- **How you'll read**: `SegmentedControl` (Read / Listen).
- **Lean the world toward…**: `SegmentedControl` (Medieval / Sci-fi / Cosy).
- CTA: `<Button variant="primary" size="lg" full>Next — build your character</Button>`.

Labels: `fonts.sans.bold` 15px `colors.textStrong`.
Sublabels: `fonts.sans.regular` 13px `colors.textMuted`.

---

### Screen 5 — Setup flow (step 2 of 2: character creation)

**Step header**: same pattern, step 2 of 2.
Title: "Now — who are you, inside it?"

**Character name row**: white card (`radius.lg`, `shadow.sm`), flex row:
- `Avatar` (56px, seat 2/periwinkle).
- `Input` placeholder "Name your character" (fill `colors.surfaceSunk`, `radius.md`, hairline border).

**Taste profile**: label + sublabel + wrapped `Tag` chips (tap to select/deselect, indigo when selected).
Items: The Lord of the Rings, Dune, The Witcher, Studio Ghibli, Disco Elysium, Le Guin,
Mistborn, Hollow Knight, Brooklyn 99, Murakami.

**Core trait**: `SegmentedControl` (Loyal / Cunning / Reckless).

**Woven preview**: dusk gradient box (`radius.lg`, pad 18):
- Mono label `TALEGATE WILL WEAVE` muted.
- Serif body 17px with bold trait word inline: "A **loyal** wanderer with a mapmaker's eye..."

**CTA**: `<Button variant="accent" size="lg" full>` with sparkles icon: "Weave the first chapter".

---

### Screen 6 — Reader (night mode, full-screen overlay)

**Background**: `colors.nightBg` (#131120). Amber radial glow at top (gradients.glow, opacity 0.5).

**Top bar** (absolute, blur gradient fade):
- Left: chevron-down icon button (plain, onNight).
- Center: `CHAPTER 12 · NIGHT 12` — `type.label`, `colors.nightMuted`.
- Right: `a-large-small` icon button (plain, onNight).

**Reading column** (scroll, pad 108 top, 26 sides, 200 bottom):
- Chapter title centered: `· The gate, or the river ·` — `type.label`, `colors.accent` (candle-400).
- Body paragraphs: `fonts.serif.regular` 20px, lineHeight 1.78, `colors.nightText`, `maxWidth: 34rem`.
- **Dropcap** on paragraph 1: first letter floated left, 58px, `fonts.serif.semibold`, `colors.accent`.
- Footer: `— your word is needed —` centered, `type.label` `colors.nightMuted`.

**Phase 1 — bottom CTA** (absolute bottom, gradient fade):
`<Button variant="accent" size="lg" full>` with git-fork icon: "The night forks — choose"

**Phase 2 — choice bottom sheet** (`colors.nightRaised`, `radius.x2l` top corners,
`borderTop: 1px solid colors.nightBorder`):
- Serif heading: "The gate, or the river?" — 22px `fonts.serif.semibold` `colors.nightText`.
- Mono sublabel: `YOUR WORD LOCKS AT 10PM` — `type.label` `colors.nightMuted`.
- 3 `Choice` components (letter A/B/C, tap to select). Choice C is "betrayal" flavor (danger tint).
- `<Button variant="accent" size="lg" full disabled={!picked}>Seal my word</Button>`.

**Phase 3 — sealed confirmation**:
- Centered amber circle (56px, `colors.accent` bg) with check icon (28px, dark, stroke 2.6).
- Serif: "Your word is sealed." 22px + body "The others have until 10pm..." 16px.
- Night-tinted `GuildDots` card showing "3 of 4 have chosen".
- `<Button variant="secondary" onNight size="lg" full>Goodnight</Button>`.

---

### Icons

Use `lucide-react-native` throughout. Stroke 1.9 default, 2.2 for active/emphasis.
Color `colors.brand` for interactive, `currentColor` for inline. Size 20–24 in UI, 18 in compact bars.

---

### What to never do

```
❌ borderRadius: 4       ✅ borderRadius: radius.sm
❌ color: '#423AA0'      ✅ color: colors.brand
❌ fontWeight: 'bold'    ✅ fontFamily: fonts.sans.bold
❌ padding: 20           ✅ padding: space[6]
❌ "Read Tonight's Chapter"  ✅ "Read tonight's chapter"
❌ emoji in buttons/labels   ✅ only 🌙 as rare notification garnish
❌ Inter, Roboto, SF Pro     ✅ Schibsted Grotesk / Newsreader / Geist Mono only
```
